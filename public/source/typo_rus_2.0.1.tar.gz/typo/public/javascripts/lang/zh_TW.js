window._lang = "zh_TW" ;
window._l10s = window._l10s || { } ;
window._l10s["zh_TW"] = {

  "#{0} from now": "距離現在#{0}",
  "#{0} ago": "#{0} 之前",
  "on #{0}": "在 #{0}",
  "less than a minute": "少於一分鐘",
  "#{0} minute": "#{0} 分鐘",
  "#{0} minutes": "#{0} 分鐘",
  "about one hour": "大約一小時",
  "#{0} hours": "#{0} 小時",
  "one day": "一天",
  "about one day": "大約一天",
  "#{0} days": "#{0} 天"

} ;