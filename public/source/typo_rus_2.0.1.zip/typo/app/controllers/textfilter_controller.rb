# TODO: Remove
class TextfilterController < ApplicationController
end

