class CategoriesController < GroupingController
  # index - inherited
  # show - inherited
end
