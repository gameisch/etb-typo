Date.weekdays = $w('Po To Sr Če Pe So Ne');
Date.months = $w('Januar Februar Marec April Maj Junij Julij Avgust September Oktober November December');

Date.first_day_of_week = 1;

_translations = {
  "OK": "OK",
  "Now": "Trenutno",
  "Today": "Danes",
  "Clear": "Pobriši"
}
