Date.weekdays = $w("L M X J V S D");
Date.months = $w("Enero Febrero Marzo Abril Mayo Junio Julio Agosto Septiembre Octubre Noviembre Diciembre" );

Date.first_day_of_week = 1;

_translations = {
  "OK": "Cancelar",
  "Now": "Ahora",
  "Clear": "Limpiar",
  "Today": "Hoy"
}