Date.weekdays = $w('Ma Di Wo Do Vr Za Zo');
Date.months = $w('januari februari maart april mei juni juli augustus september oktober november december');

Date.first_day_of_week = 1;

_translations = {
  "OK": "OK",
  "Now": "Nu",
  "Today": "Vandaag",
  "Clear": "Wissen"
}
