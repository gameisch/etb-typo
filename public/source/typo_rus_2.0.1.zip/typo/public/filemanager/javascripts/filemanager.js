/**
 * @author leon.li
 */
window.onload = function() {
	translatePage();
}
